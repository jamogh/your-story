import SwiftUI

@main
struct StoryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
