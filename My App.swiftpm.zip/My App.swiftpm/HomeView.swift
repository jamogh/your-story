import SwiftUI

struct HomeView: View {
    
    var body: some View {
        ZStack{
            Image("image")
                .resizable()
            VStack {
                Spacer()
                Text("All About")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()
                    .foregroundStyle(.black)
                
                Image(information.image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(10)
                    .padding(10)
                
                Text(information.name)
                    .font(.title)
                    .fontWeight(.semibold)
                    .padding()
                    .foregroundStyle(.black)
                Spacer()
            }
        }
        
    }
    
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
