import Foundation
import SwiftUI

struct Info {
    let image: String
    let name: String
    let story_template: String
    let story: String
    let hobbies: [String]
    let foods: [String]
    let colors: [Color]
    let funFacts_template : [String]
    let funFacts: [String]
}

let information = Info(
    image: "clouds",
    name: "Your Story",
    story_template: "A story can be about anything you can dream up. There are no right answers, there is no one else.\n\nNeed some inspiration?\n• 🐶🐱🛶️🎭🎤🎧🎸\n• 🏄‍♀️🚵‍♀️🚴‍♀️⛵️🥾🏂⛷📚\n• ✍️🥖☕️🏋️‍♂️🚲🧗‍♀️ ",
    story: "Ok, so lets build a story based on your choices, I will provide you start of the story to build a base, rest all depends on you , which I think is quite inspirational.\n though remember that the story must end in a single way! Rest all the ways you try will to the break in story! ",
    hobbies: ["bicycle", "guitars", "camera.fill"],
    foods: ["🌯", "🌮", "☕️"],
    colors: [Color.white, Color.purple, Color.orange],
    funFacts_template: [
        "The femur is the longest and largest bone in the human body.",
        "The moon is 238,900 miles away.",
        "India has 22 official Languages.",
        "India has the largest population of vegetarians in the world.",
        "Ice is 9 percent less dense than liquid water.",
        "You can spell every number up to 1,000 without using the letter A.\n\n...one, two, three, four...ninety-nine...nine hundred ninety-nine 🧐",
        "A collection of hippos is called a bloat.",
        "White sand beaches are made of parrotfish poop.😵‍💫",
    ],
    funFacts: [
        "The femur is the longest and largest bone in the human body.",
        "The moon is 238,900 miles away.",
        "India has 22 official Languages.",
        "India has the largest population of vegetarians in the world.",
        "Ice is 9 percent less dense than liquid water.",
        "You can spell every number up to 1,000 without using the letter A.\n\n...one, two, three, four...ninety-nine...nine hundred ninety-nine 🧐",
        "A collection of hippos is called a bloat.",
        "White sand beaches are made of parrotfish poop.😵‍💫",
    ]
)
